# Student Grade Calculator

## Module 02 - Python Mini Project

A simple Python program that calculates a student's total marks, average percentage, and grade.

### Features
- Takes the student's name.
- Accepts marks for multiple subjects.
- Validates marks from 0 to 100.
- Calculates total and average.
- Displays a grade and result.

### Grade Scale
- 90–100: A+
- 80–89.99: A
- 70–79.99: B
- 60–69.99: C
- 40–59.99: D
- Below 40: F

### How to Run
Run this command in a terminal:

```bash
python main.py
```

### Python Concepts Used
Variables, input/output, data types, lists, loops, conditions, functions, exception handling, and arithmetic operations.
