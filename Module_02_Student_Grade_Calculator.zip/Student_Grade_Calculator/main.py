# Student Grade Calculator - Module 02

def calculate_grade(average):
    if average >= 90:
        return "A+"
    elif average >= 80:
        return "A"
    elif average >= 70:
        return "B"
    elif average >= 60:
        return "C"
    elif average >= 40:
        return "D"
    return "F"

def main():
    print("===== Student Grade Calculator =====")
    name = input("Enter student name: ")
    try:
        count = int(input("Enter number of subjects: "))
        if count <= 0:
            print("Enter at least one subject.")
            return

        marks = []
        for i in range(count):
            while True:
                try:
                    mark = float(input(f"Enter marks for subject {i + 1} (0-100): "))
                    if 0 <= mark <= 100:
                        marks.append(mark)
                        break
                    print("Marks must be between 0 and 100.")
                except ValueError:
                    print("Please enter a valid number.")

        total = sum(marks)
        average = total / count
        grade = calculate_grade(average)

        print("\n===== Student Result =====")
        print("Name:", name)
        print(f"Total: {total:g} / {count * 100}")
        print(f"Average: {average:.2f}%")
        print("Grade:", grade)
        print("Result:", "Pass" if grade != "F" else "Needs improvement")
    except ValueError:
        print("Please enter a valid number of subjects.")

if __name__ == "__main__":
    main()
